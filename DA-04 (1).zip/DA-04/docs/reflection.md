# Individual reflection: Mayank Swaraj (DA-04)
Draft for you to edit in your own words.
I owned the full pipeline: synthetic ledger and customer data, the credit scorecard, variance logic and the dashboard. I learned how a scorecard turns probability of default into a points scale and risk bands, and how to calibrate cut-offs to the score distribution. A test caught that my injected Services shortfall was too small to trigger the flag, which showed me the value of testing business rules. With more time I would load the data into PostgreSQL and schedule refreshes with Airflow.
