# Architecture
```
 gen_ledger() ─┐                          ┌─> P&L (monthly, actual vs budget)
               ├─> data/gl_ledger.csv ───>├─> Budget vs actual + flags (>5% adverse)
 gen_customers()┐                         └─> Board-pack narrative
               └─> fit_scorecard() ─> data/customers_scored.csv ─> bands, top-10, drivers
                                   all ─> dashboard_template.html ─> dashboard.html (self-contained)
```
Data dictionary: gl_ledger(month, account, type, budget, actual); customers_scored(id, income, debt_ratio, late_payments, utilization, tenure_years, defaulted, pd, score, band). Postgres DDL in `schema.sql`.
Design choices: no external services, seeded for reproducibility, UI offline with canvas charts. Next steps: load into Postgres, schedule with Airflow, swap synthetic data for real GL exports.
