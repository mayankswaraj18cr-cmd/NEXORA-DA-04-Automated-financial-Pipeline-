# 10-minute presentation outline
1. Problem (1 min): manual month-end finance reports are slow and error-prone.
2. Design (2 min): architecture diagram from architecture.md.
3. Live demo (3 min): Overview, P&L, Budget vs Actual flags, Credit Risk, Board Pack print.
4. Challenges (1.5 min): calibrating score bands; making flags meaningful; offline charts without libraries.
5. Results (1.5 min): scorecard AUC and band split (docs/metrics.json), tests passing (docs/test_results.md).
6. Next steps (1 min): Postgres + Airflow scheduling, real data, PDF board pack automation.
