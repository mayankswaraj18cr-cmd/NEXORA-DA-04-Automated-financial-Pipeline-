# Test results (pytest)
```
tests/test_pipeline.py::test_ledger_shape_and_determinism PASSED         [ 16%]
tests/test_pipeline.py::test_pnl_identity PASSED                         [ 33%]
tests/test_pipeline.py::test_variance_flags_injected_issues PASSED       [ 50%]
tests/test_pipeline.py::test_scorecard_quality_and_ranges PASSED         [ 66%]
tests/test_pipeline.py::test_score_monotonic PASSED                      [ 83%]
tests/test_pipeline.py::test_default_rate_sane PASSED                    [100%]
============================== 6 passed in 1.15s ===============================
```
Scorecard hold-out AUC: 0.771 (70/30 split, seeded). Risk bands: {'Low': 255, 'Medium': 304, 'High': 255, 'Very High': 186}.
