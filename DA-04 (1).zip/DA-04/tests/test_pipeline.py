import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pipeline as p

def test_ledger_shape_and_determinism():
    a, b = p.gen_ledger(), p.gen_ledger()
    assert len(a) == 12 * len(p.ACCTS) and a == b

def test_pnl_identity():
    for r in p.pnl(p.gen_ledger()):
        for k in ("actual", "budget"):
            x = r[k]
            assert abs(x["net"] - (x["revenue"] - x["cogs"] - x["opex"])) < 1e-6
            assert abs(x["gross"] - (x["revenue"] - x["cogs"])) < 1e-6

def test_variance_flags_injected_issues():
    flags = {b["account"]: b["flag"] for b in p.budget_vs_actual(p.gen_ledger())}
    assert flags["Marketing"] == "Over budget" and flags["Services"] == "Below target"

def test_scorecard_quality_and_ranges():
    c = p.gen_customers(); m = p.fit_scorecard(c)
    assert m["auc"] > 0.70
    assert all(300 <= x["score"] <= 850 for x in c)
    assert {x["band"] for x in c} <= {b for b, _ in p.BANDS}

def test_score_monotonic():
    assert p.to_score([0.02])[0] > p.to_score([0.30])[0]

def test_default_rate_sane():
    c = p.gen_customers(); r = sum(x["defaulted"] for x in c) / len(c)
    assert 0.05 < r < 0.25
