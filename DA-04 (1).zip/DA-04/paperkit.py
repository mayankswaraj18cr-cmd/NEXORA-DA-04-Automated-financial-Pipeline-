"""HAECS-style research paper builder (ReportLab): blue #1a3c6e titles, grey-ruled header, justified Helvetica 10pt,
cover summary box, source-code appendix, closing quote."""
import os, re, textwrap
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, Preformatted, SimpleDocTemplate, Spacer, Table, TableStyle)

BLUE, GREY, LIGHT = colors.HexColor("#1a3c6e"), colors.HexColor("#8a8f98"), colors.HexColor("#eef2f9")
ST = dict(
    title=ParagraphStyle("t", fontName="Helvetica-Bold", fontSize=19, leading=24, textColor=BLUE, alignment=TA_CENTER, spaceAfter=8),
    sub=ParagraphStyle("s", fontName="Helvetica-Oblique", fontSize=10.5, leading=14, textColor=GREY, alignment=TA_CENTER, spaceAfter=4),
    h1=ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=13, leading=17, textColor=BLUE, spaceBefore=12, spaceAfter=5),
    h2=ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=10.5, leading=14, textColor=BLUE, spaceBefore=7, spaceAfter=3),
    body=ParagraphStyle("b", fontName="Helvetica", fontSize=10, leading=14, alignment=TA_JUSTIFY, spaceAfter=6),
    bul=ParagraphStyle("bl", fontName="Helvetica", fontSize=10, leading=13.5, alignment=TA_JUSTIFY, leftIndent=14, bulletIndent=3, spaceAfter=2),
    cell=ParagraphStyle("c", fontName="Helvetica", fontSize=8.3, leading=10.5),
    cellh=ParagraphStyle("ch", fontName="Helvetica-Bold", fontSize=8.3, leading=10.5, textColor=colors.white),
    cap=ParagraphStyle("cp", fontName="Helvetica-Oblique", fontSize=8.5, leading=11, textColor=GREY, alignment=TA_CENTER, spaceAfter=8),
    ref=ParagraphStyle("r", fontName="Helvetica", fontSize=9, leading=12, leftIndent=14, firstLineIndent=-14, spaceAfter=3),
    quote=ParagraphStyle("q", fontName="Helvetica-Oblique", fontSize=11, leading=16, textColor=BLUE, alignment=TA_CENTER, spaceBefore=18),
    sig=ParagraphStyle("sg", fontName="Helvetica-Bold", fontSize=10, textColor=BLUE, alignment=TA_CENTER, spaceBefore=4),
    box=ParagraphStyle("bx", fontName="Helvetica", fontSize=9.3, leading=12.8, alignment=TA_JUSTIFY, spaceAfter=3),
)
P = lambda t, s="body": Paragraph(re.sub(r"&(?!amp;|lt;|gt;|nbsp;|ldquo;|rdquo;)", "&amp;", t), ST[s])


def table(rows, widths=None, zebra=True):
    data = [[P(str(c), "cellh") if i == 0 else P(str(c), "cell") for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=widths, repeatRows=1)
    st = [("BACKGROUND", (0, 0), (-1, 0), BLUE), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#c9ced6")),
          ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if zebra:
        st += [("BACKGROUND", (0, i), (-1, i), LIGHT) for i in range(2, len(rows), 2)]
    t.setStyle(TableStyle(st)); return t


def blocks(items):
    out = []
    for b in items:
        if isinstance(b, str): out.append(P(b))
        elif b[0] == "h2": out.append(P(b[1], "h2"))
        elif b[0] == "bul": out += [Paragraph("&bull; " + re.sub(r"&(?!amp;|lt;|gt;)", "&amp;", x), ST["bul"]) for x in b[1]] + [Spacer(1, 4)]
        elif b[0] == "table": out += [KeepTogether([P(b[2], "cap"), table(b[1], b[3] if len(b) > 3 else None)]), Spacer(1, 6)]
        elif b[0] == "fig":
            im = Image(b[1], width=b[3] * mm, height=b[3] * mm * b[4]); out.append(KeepTogether([im, P(b[2], "cap")]))
        elif b[0] == "eq": out.append(Preformatted(b[1], ParagraphStyle("eq", fontName="Courier", fontSize=9, leading=12, leftIndent=24, spaceAfter=6, textColor=BLUE)))
    return out


def wrap_code(path, width=118):
    lines = []
    for ln in open(path, encoding="utf-8").read().expandtabs(4).splitlines():
        lines += textwrap.wrap(ln, width, subsequent_indent="      ", replace_whitespace=False, drop_whitespace=False) or [""]
    return "\n".join(lines)


def build(out, title, subtitle, running, summary, sections, refs, quote, code_files):
    def deco(c, d):
        c.saveState(); w, h = A4
        c.setFont("Helvetica", 7.5); c.setFillColor(GREY); c.drawString(18 * mm, h - 11 * mm, running); c.drawRightString(w - 18 * mm, h - 11 * mm, "Mayank Swaraj | Nexvia Capstone")
        c.setStrokeColor(GREY); c.setLineWidth(0.5); c.line(18 * mm, h - 13 * mm, w - 18 * mm, h - 13 * mm); c.line(18 * mm, 13 * mm, w - 18 * mm, 13 * mm)
        c.drawCentredString(w / 2, 8.5 * mm, f"Page {d.page}"); c.restoreState()
    doc = SimpleDocTemplate(out, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=20 * mm, bottomMargin=19 * mm, title=title, author="Mayank Swaraj")
    s = [Spacer(1, 14), P(title, "title"), P(subtitle, "sub"), P("Mayank Swaraj | Mayank Creations | Nexvia Technologies Capstone | October 2026", "sub"), Spacer(1, 10)]
    box = Table([[[P("<b>Summary</b>", "box")] + [Paragraph("&bull; " + re.sub(r"&(?!amp;|lt;|gt;)", "&amp;", x), ST["box"]) for x in summary]]], colWidths=[174 * mm])
    box.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 1, BLUE), ("BACKGROUND", (0, 0), (-1, -1), LIGHT), ("LEFTPADDING", (0, 0), (-1, -1), 9), ("RIGHTPADDING", (0, 0), (-1, -1), 9), ("TOPPADDING", (0, 0), (-1, -1), 7), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
    s += [box, Spacer(1, 6)]
    for h, items in sections: s += [P(h, "h1")] + blocks(items)
    s += [P("References", "h1")] + [P(r, "ref") for r in refs] + [P(f"&ldquo;{quote}&rdquo;", "quote"), P("Mayank Swaraj", "sig")]
    s += [PageBreak(), P("Appendix: Source Code Listings", "h1"),
          P("Complete source of the system described above. Long lines are wrapped with a six-space continuation indent. The browser dashboard template (dashboard_template.html) and generated dashboard.html are delivered alongside this PDF.")]
    for i, (label, path) in enumerate(code_files, 1):
        s += [P(f"Listing {i}: {label}", "h2"), Preformatted(wrap_code(path), ParagraphStyle("code", fontName="Courier", fontSize=6.4, leading=7.8, backColor=colors.HexColor("#f6f7f9"), borderPadding=3, spaceAfter=10))]
    doc.build(s, onFirstPage=deco, onLaterPages=deco)
