"""DA-04 Financial Analytics & Risk Reporting System.
Generates ledger/budget/customer data, fits a credit scorecard, builds P&L,
budget-vs-actual and a board pack, and writes dashboard.html. Run: python pipeline.py"""
import csv, json, math, os
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler

ROOT = os.path.dirname(os.path.abspath(__file__))
MONTHS = [f"2025-{m:02d}" for m in range(1, 13)]
ACCTS = [("Product Sales", "Revenue", 520000), ("Services", "Revenue", 180000),
         ("Subscriptions", "Revenue", 140000), ("Cost of Goods Sold", "COGS", 380000),
         ("Salaries", "Opex", 210000), ("Marketing", "Opex", 70000),
         ("Rent", "Opex", 40000), ("Software", "Opex", 25000), ("Travel", "Opex", 18000)]
FEATURES = ["income", "debt_ratio", "late_payments", "utilization", "tenure_years"]
BANDS = [("Low", 640), ("Medium", 600), ("High", 560), ("Very High", 0)]


def gen_ledger(seed=42):
    rng = np.random.default_rng(seed)
    rows = []
    for i, m in enumerate(MONTHS):
        season = 1 + 0.12 * math.sin(2 * math.pi * (i - 2) / 12)
        for a, t, b in ACCTS:
            bud = round(b * (1 + 0.01 * i), 2)
            f = season if t in ("Revenue", "COGS") else 1
            act = bud * f * (1 + rng.normal(0, 0.04))
            if a == "Marketing" and m in ("2025-07", "2025-08", "2025-09"):
                act *= 1.25  # injected overspend
            if a == "Services" and i >= 6:
                act *= 0.88  # injected shortfall
            rows.append(dict(month=m, account=a, type=t, budget=bud, actual=round(act, 2)))
    return rows


def gen_customers(n=1000, seed=7):
    r = np.random.default_rng(seed)
    income = r.lognormal(10.8, 0.4, n).round(0)
    dti = r.beta(2, 5, n).round(3)
    late = r.poisson(1.2, n)
    util = r.beta(2, 3, n).round(3)
    ten = r.integers(1, 15, n)
    z = -3.2 + 3.0 * dti + 0.45 * late + 1.8 * util - 0.08 * ten - 0.00001 * income
    d = (r.random(n) < 1 / (1 + np.exp(-z))).astype(int)
    return [dict(id=f"C{i+1:04d}", income=income[i], debt_ratio=dti[i], late_payments=int(late[i]),
                 utilization=util[i], tenure_years=int(ten[i]), defaulted=int(d[i])) for i in range(n)]


def to_score(pd_):
    pd_ = np.clip(pd_, 1e-4, 1 - 1e-4)
    s = 650 + (40 / math.log(2)) * np.log((1 - pd_) / pd_ / 20)
    return np.clip(np.round(s), 300, 850).astype(int)


def band(s):
    return next(b for b, lo in BANDS if s >= lo)


def fit_scorecard(cust, seed=1):
    X = np.array([[c[f] for f in FEATURES] for c in cust], float)
    y = np.array([c["defaulted"] for c in cust])
    idx = np.random.default_rng(seed).permutation(len(y))
    cut = int(0.7 * len(y))
    tr, te = idx[:cut], idx[cut:]
    sc = StandardScaler().fit(X[tr])
    m = LogisticRegression(max_iter=1000).fit(sc.transform(X[tr]), y[tr])
    auc = roc_auc_score(y[te], m.predict_proba(sc.transform(X[te]))[:, 1])
    pdv = m.predict_proba(sc.transform(X))[:, 1]
    scores = to_score(pdv)
    for c, p, s in zip(cust, pdv, scores):
        c.update(pd=round(float(p), 4), score=int(s), band=band(int(s)))
    return dict(auc=round(float(auc), 3), coefs={f: round(float(w), 3) for f, w in zip(FEATURES, m.coef_[0])},
                train=int(cut), test=int(len(y) - cut))


def pnl(ledger):
    out = []
    for m in MONTHS:
        r = {"month": m}
        for k in ("actual", "budget"):
            g = lambda t: sum(x[k] for x in ledger if x["month"] == m and x["type"] == t)
            rev, cogs, opex = g("Revenue"), g("COGS"), g("Opex")
            r[k] = dict(revenue=rev, cogs=cogs, gross=rev - cogs, opex=opex, net=rev - cogs - opex)
        out.append(r)
    return out


def budget_vs_actual(ledger):
    out = []
    for a, t, _ in ACCTS:
        bud = sum(x["budget"] for x in ledger if x["account"] == a)
        act = sum(x["actual"] for x in ledger if x["account"] == a)
        fav = (act - bud) if t == "Revenue" else (bud - act)
        pct = fav / bud * 100
        out.append(dict(account=a, type=t, budget=bud, actual=act, fav=fav, fav_pct=pct,
                        flag="Over budget" if (t != "Revenue" and pct < -5) else
                             "Below target" if (t == "Revenue" and pct < -5) else "OK"))
    return out


def narrative(pl, bva, cust, model):
    A = lambda k: sum(r["actual"][k] for r in pl)
    B = lambda k: sum(r["budget"][k] for r in pl)
    n = []
    n.append(f"Revenue for FY2025 was {A('revenue'):,.0f} against a budget of {B('revenue'):,.0f} ({(A('revenue')/B('revenue')-1)*100:+.1f}%).")
    n.append(f"Net income was {A('net'):,.0f} versus a budgeted {B('net'):,.0f} ({(A('net')/B('net')-1)*100:+.1f}%).")
    bad = sorted([b for b in bva if b["flag"] != "OK"], key=lambda b: b["fav_pct"])[:3]
    if bad:
        n.append("Attention items: " + "; ".join(f"{b['account']} ({b['fav_pct']:+.1f}% vs budget, {b['flag'].lower()})" for b in bad) + ".")
    hi = sum(c["band"] in ("High", "Very High") for c in cust) / len(cust) * 100
    dr = sum(c["defaulted"] for c in cust) / len(cust) * 100
    n.append(f"Credit book: {len(cust)} customers, observed default rate {dr:.1f}%, {hi:.1f}% in High/Very High risk bands. Scorecard AUC on hold-out: {model['auc']}.")
    return n


def write_csv(path, rows):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


def build():
    led, cust = gen_ledger(), gen_customers()
    model = fit_scorecard(cust)
    pl, bva = pnl(led), budget_vs_actual(led)
    write_csv(f"{ROOT}/data/gl_ledger.csv", led)
    write_csv(f"{ROOT}/data/customers_scored.csv", cust)
    bands = {b: sum(c["band"] == b for c in cust) for b, _ in BANDS}
    data = dict(months=MONTHS, pl=pl, bva=bva, model=model, bands=bands, narrative=narrative(pl, bva, cust, model),
                top=sorted(cust, key=lambda c: c["score"])[:10], n=len(cust),
                default_rate=round(sum(c["defaulted"] for c in cust) / len(cust) * 100, 2))
    json.dump(dict(auc=model["auc"], bands=bands, default_rate=data["default_rate"]), open(f"{ROOT}/docs/metrics.json", "w"), indent=1)
    html = open(f"{ROOT}/dashboard_template.html", encoding="utf-8").read().replace("__DATA__", json.dumps(data))
    open(f"{ROOT}/dashboard.html", "w", encoding="utf-8").write(html)
    return data


if __name__ == "__main__":
    d = build()
    print("AUC", d["model"]["auc"], "| bands", d["bands"], "| dashboard.html written")
