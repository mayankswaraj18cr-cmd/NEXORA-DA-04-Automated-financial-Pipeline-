-- PostgreSQL schema (load CSVs from data/ with \copy)
CREATE TABLE gl_ledger (month CHAR(7), account TEXT, type TEXT CHECK (type IN ('Revenue','COGS','Opex')), budget NUMERIC(14,2), actual NUMERIC(14,2));
CREATE TABLE customers_scored (id TEXT PRIMARY KEY, income NUMERIC, debt_ratio NUMERIC, late_payments INT, utilization NUMERIC, tenure_years INT, defaulted SMALLINT, pd NUMERIC(6,4), score INT, band TEXT);
