# DA-04 Financial Analytics and Risk Reporting System
Automated P&L, budget vs actual, credit risk scoring and a monthly board pack (synthetic FY2025 data).

## Run
```
pip install numpy scikit-learn pytest matplotlib reportlab
python pipeline.py        # regenerates data/*.csv, docs/metrics.json, dashboard.html
python -m pytest tests    # 6 tests
```
Open `dashboard.html` in any browser (no server, no internet). Tabs: Overview, P&L, Budget vs Actual, Credit Risk, Board Pack (use Print / Save as PDF).

## Files
- `pipeline.py` data generation, logistic-regression scorecard, P&L, variance flags, board-pack narrative
- `dashboard_template.html` / `dashboard.html` UI template and generated dashboard
- `DA-04_Research_Paper_and_Source.pdf` research paper plus full source listings (built by `build_paper.py`, helper `paperkit.py`; needs matplotlib and reportlab)
- `schema.sql` PostgreSQL tables for the two CSVs in `data/`
- `docs/` architecture, test results, presentation outline, reflection
- `tests/` pytest suite

## Method
Ledger: 9 accounts x 12 months with seasonality and two injected issues (Marketing overspend Jul-Sep, Services shortfall Jul-Dec) so variance flags have something to find. Credit: 1,000 customers, 5 features, scorecard score = 650 + (40/ln2)·ln(odds/20), bands Low >=640, Medium >=600, High >=560, else Very High.
